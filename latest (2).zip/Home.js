import React, {Component} from 'react';
import {Platform,Keyboard,Modal,ActivityIndicator, ToastAndroid,Slider, CheckBox, ScrollView, StyleSheet,TouchableOpacity, Text, View,Image,Dimensions,Linking, TextInput,TouchableWithoutFeedback, FlatList } from 'react-native';
import { theme } from './lib/theme';
import { baseurl, get, post } from './lib/utilies';
import Icon from 'react-native-vector-icons/FontAwesome';
import HouseDetails from './resources/HouseDetails';
import Search from './resources/Search';
import Area from './resources/area.json';
import _ from 'lodash';
import axios from 'axios';
import HouseList from './resources/HouseList';
import moment from 'moment';

let {width,height} = Dimensions.get('window');

import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';


type Props = {};
@inject('Store')
@observer
export default class Home extends Component<Props> {

    constructor(props){
        super(props);
        this.state = {
            watchChange:false,
            searchText:'',
            filteredArea:[],
            selectedArea:'',
            showDetails: false,
        };
    }

    componentWillMount(){
        
    }

    openHouse = (item) => {
        this.setState({showDetails:true})
        this.props.Store.houseDetails = item;
    }

    hideDetails = () => {
        this.setState({showDetails:false});
    }

    // openHouse = (item) => {
    //     //alert("hello")
    //     this.props.Store.houseDetails = item;
    //     //this.props.navigation.navigate('HouseDetails');
    // }

    render() {

        return (
            <View style={{flex:1, backgroundColor:'#fff'}}>
                <Search />
                {(this.props.Store.searching && this.props.Store.search.length == 0) &&
                    <Text style={{textAlign:'center', fontSize:14, color:'#000', fontWeight:'bold', marginTop:20}}>No House Found</Text>
                }
                
                <FlatList style={{height:'100%'}}
                    data={this.props.Store.searching ? this.props.Store.search : this.props.Store.houses}
                    showsVerticalScrollIndicator={false}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({item, index}) => 

                        <TouchableWithoutFeedback onPress={() => this.openHouse(item)}>
                            <View style={[{height:260, width:width*.9,alignSelf:'center',marginTop:10,position:'relative', borderRadius:5, marginBottom:10}, styles.shadow]}>
                                <Image 
                                    style={{height:220,width:'100%',resizeMode:'cover', borderTopRightRadius:5, borderTopLeftRadius:5}}
                                    source={{uri: baseurl()+'/img/'+JSON.parse(item.image)[0]}}
                                />
                                <View style={{height:40,flexDirection:'row', alignItems:'center', justifyContent:'space-around'}}>
                                    <Text style={styles.shortDetailsText}><Icon name="bed" size={12} /> {item.room} room</Text>
                                    <Text style={styles.shortDetailsText}><Icon name="bath" size={12} /> {item.bath} Bathroom</Text>
                                    <Text style={styles.rent}>{item.square} sq ft</Text>
                                </View>
                                <View style={{position:'absolute',height:35, bottom:40, left:0,right:0, backgroundColor:'rgba(0,0,0,0.5)',paddingLeft:10, paddingTop:6, flexDirection:'row'}}>
                                    <Text style={{color:'#fff', opacity:.8, fontSize:16, fontWeight:'900'}}>৳{item.cost}</Text>
                                    <Text style={{paddingTop:3,color:'#fff', fontSize:12}}> {item.type === 'Sale' ? '' : 'per month'}</Text>
                                </View>
                                <Text style={[styles.absoluteText, {left:10}]}>{item.type}</Text>
                                <Text style={[styles.absoluteText, {right:10}]}>Avaliable Form: {moment(item.valid_date).format('MMMM YY')}</Text>
                                <Text style={[styles.absoluteText, {top:190, left:'auto', right:10}]}><Icon name="map-marker" size={12} /> {item.area}</Text>
                            </View>
                        </TouchableWithoutFeedback>

                    }
                    />
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={this.state.showDetails}
                    onRequestClose={() => {
                        this.setState({
                            showDetails:false
                        })
                    }}
                >
                    <HouseDetails hideDetails={this.hideDetails}  />
                </Modal>
                {/* <View style={[StyleSheet.absoluteFill, {opacity:this.state.showDetails?1:0}]} pointerEvents={this.state.showDetails ? 'auto' : 'none'}>
                    <HouseDetails hideDetails={this.hideDetails}  />
                </View> */}
                <Modal
                    animationType="none"
                    transparent={true}
                    visible={this.props.Store.loading}
                    onRequestClose={() => {
                        console.log('sd')
                    }}
                >
                    <View style={{flex:1,backgroundColor:'rgba(0,0,0,0.5)', justifyContent:'center', alignItems:'center'}}>
                        <ActivityIndicator color='#fff' size='large' />
                    </View>
                </Modal>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    shortDetailsText:{
        color:theme().clr,
        fontSize:14,
        fontWeight:'600',
    },
    rent:{
        color:'#a3176e',
        fontSize:14,
        fontWeight:'500'
    },
    absoluteText:{
        position:'absolute',
        paddingHorizontal:10,
        paddingVertical:3,
        borderRadius:20,
        backgroundColor:'rgba(0,0,0,0.5)',
        color:'#fff',
        fontSize:12,
        fontWeight:'bold',
        top:10,
        opacity:.8
    },
    shadow:{
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 6,
        },
        shadowOpacity: 0.8,
        shadowRadius: 10,
        elevation: 5,
    },
    detailsAbsBtn:{
        position:'absolute', 
        top:10,
        height:50, 
        width:50, 
        alignItems:'center', 
        justifyContent:'center',
        backgroundColor:'rgba(0,0,0,.3)',
        borderRadius:5
    },
});
