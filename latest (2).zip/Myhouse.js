import React, {Component} from 'react';
import {Platform, StyleSheet,WebView,TouchableWithoutFeedback,TouchableOpacity, Image, ToastAndroid, Modal,KeyboardAvoidingView,FlatList, ImageBackground,AsyncStorage, ScrollView,Alert, Dimensions, Text,TextInput, View} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import moment from 'moment';
import { theme } from './lib/theme';
import Login from './Login';
import {setLocal, getLocal, post, baseurl} from './lib/utilies';
import AddHouse from './AddHouse';
import HouseDetails from './resources/HouseDetails';

let {width,height} = Dimensions.get('window');


import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';

type Props = {};
@inject('Store')
@observer
export default class Myhouse extends Component<Props> {

  constructor(props) {
      super(props);
      this.state = {
          watchChange: true,
          showAddHouse: false,
          activeHouse: null,
          showDetails: false,

          shownType:'1',
      };
  }

  setPendingUser = (mobile, pass) => {
    this.setState({pendingMobile:mobile});
    this.setState({pendingPass:pass});
  }


  changePage = (value) =>{
    this.setState({activeHouse: null, page:value});
  }

  showAddhouse = (house) => {
    this.setState({showAddHouse:true,activeHouse:house});
  }

  showHouseDetails = (item) => {
    this.setState({showDetails:true})
    this.props.Store.houseDetails = item;
  }

  hideAddhouse = () => {
    this.setState({showAddHouse:false, activeHouse:null});
  }

  hideDetails = () => {
    this.setState({showDetails:false});
  }

  toogleShowType = (type) => {
    this.setState({shownType: type});
  }  

  toogleActDeactiveAlert(item){
    Alert.alert(
      item.status == '1' ? "Deativate House" : "Activate House",
      item.status == '1' ? "People will no longer see it" : "People will see this house again",
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => this.toogleActDeactive(item)},
      ],
      {cancelable: false},
    );
  }

  toogleActDeactive = (item) => {
    this.props.Store.loading = true;
    let {user} = this.props.Store;
    post(item.status == '1' ? '/public/api/adds/deactivate' : "/public/api/adds/activate", {
        mobile:user.mobile, 
        token:user.token,
        id:item.id,
    }, (response) => {
        if(response.data.success){
          this.props.Store.loading = false;
          ToastAndroid.show(item.status == '1' ? 'House Deactivated' : "House Activated", 1000);
          this.getAllHouseWithMy();
        }else{
          this.props.Store.loading = false;
          ToastAndroid.show(response.data.msg, 1000);
        }
    });
  }

  deleteAlert(item){
    Alert.alert(
      "Delete House?",
      "House will be deleted permanently",
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => this.delete(item)},
      ],
      {cancelable: false},
    );
  }

  delete = (item) => {
    this.props.Store.loading = true;
    let {user} = this.props.Store;
    post('/public/api/adds/delete', {
        mobile:user.mobile, 
        token:user.token,
        id:item.id,
    }, (response) => {
        if(response.data.success){
          this.props.Store.loading = false;
          ToastAndroid.show("House Deleted", 1000);
          this.getAllHouseWithMy()
        }else{
          this.props.Store.loading = false;
          ToastAndroid.show(response.data.msg, 3000);
        }
    });
  }

  getAllHouseWithMy = () => {
      post('/public/api/adds/withmyhouse',{
        mobile:this.props.Store.user.mobile,
        token:this.props.Store.user.token
      }, (response) => {
        if(response.data.success){
          this.props.Store.houses = response.data.Adds;
          this.props.Store.myhouse = response.data.Myhouse;
        }
      })
  }

  render() {
    
    let {myhouse, user} = this.props.Store;

    return (
        <KeyboardAvoidingView enabled style={{backgroundColor:'#fff', flex:1}}>
          {(user.length == 0) && 
            <Login changePage={this.changePage} getAllHouseWithMy={this.getAllHouseWithMy} />
          }
          {(user.length != 0) && 
            <View style={{position:'relative', flex:1}}>
              <View style={styles.newHead}>
                <Text style={styles.newHeadText}><Icon name="map-signs" size={30} /> MY HOUSE</Text>
              </View>

              
              {(myhouse.length == 0) &&
                <View style={{flex:1, alignItems:'center', justifyContent:'center'}}>
                  <Text style={styles.noItemText}>House list empty</Text>
                  <TouchableWithoutFeedback onPress={() => this.setState({showAddHouse:true})}>
                    <View style={[styles.addEmptyBtn, styles.shadow]}>
                      <Text style={styles.addEmptyBtnText}><Icon name="plus" size={14} /> Add</Text>
                    </View>
                  </TouchableWithoutFeedback>
                </View>
              }

              {(myhouse.length > 0) &&
              <View style={styles.activeBtnWrapper}>
                <TouchableWithoutFeedback onPress={() => this.toogleShowType(1)}>
                  <View style={[styles.activeBtn, {backgroundColor:this.state.shownType == 1 ? "#000" : "#fff" }]}>
                    <Text style={[styles.activeBtnText, {color:this.state.shownType == 1 ? "#fff" : "#000" }]}>Active</Text>
                  </View>
                </TouchableWithoutFeedback>
                <TouchableWithoutFeedback onPress={() => this.toogleShowType(0)}>
                  <View style={[styles.activeBtn, {backgroundColor:this.state.shownType != 1 ? "#000" : "#fff" }]}>
                    <Text style={[styles.activeBtnText, {color:this.state.shownType != 1 ? "#fff" : "#000" }]}>Deactivated</Text>
                  </View>
                </TouchableWithoutFeedback>
              </View>
              }
              
              <FlatList
                data={myhouse}
                extraData={this.state.shownType}
                showsVerticalScrollIndicator={false}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({item, index}) => {
                  if(item.status == this.state.shownType){
                    return (
                      <View style={[{height:300, width:width*.9,alignSelf:'center',marginTop:10,position:'relative', borderRadius:5, marginBottom:10}, styles.shadow]}>
                          <Image 
                              style={{height:220,width:'100%',resizeMode:'cover', borderTopRightRadius:5, borderTopLeftRadius:5}}
                              source={{uri: baseurl()+'/img/'+JSON.parse(item.image)[0]}}
                          />
                          <View style={{height:40,flexDirection:'row', alignItems:'center', justifyContent:'space-around'}}>
                              <Text style={styles.shortDetailsText}><Icon name="bed" size={12} /> {item.room} room</Text>
                              <Text style={styles.shortDetailsText}><Icon name="bath" size={12} /> {item.bath} Bathroom</Text>
                              <Text style={styles.rent}>{item.square} sq ft</Text>
                          </View>
                          <View style={{position:'absolute',height:35, bottom:80, left:0,right:0, backgroundColor:'rgba(0,0,0,0.5)',paddingLeft:10, paddingTop:6, flexDirection:'row'}}>
                              <Text style={{color:'#fff', opacity:.8, fontSize:16, fontWeight:'900'}}>৳{item.cost}</Text>
                              <Text style={{paddingTop:3,color:'#fff', fontSize:12}}> {item.type === 'Sale' ? '' : 'per month'}</Text>
                          </View>
                          <Text style={[styles.absoluteText, {left:10}]}>{item.type}</Text>
                          <Text style={[styles.absoluteText, {right:10}]}>Avaliable Form: {moment(item.valid_date).format('MMMM YY')}</Text>
                          <Text style={[styles.absoluteText, {top:190, left:'auto', right:10}]}><Icon name="map-marker" size={12} /> {item.area}</Text>
                          <View style={{height:40, flexDirection:'row', justifyContent:'flex-end', alignItems:'center', paddingHorizontal:20}}>
                            <TouchableWithoutFeedback onPress={() => this.showHouseDetails(item)}>
                              <View style={styles.updateBtn}>
                                <Text style={styles.updateBtnText}><Icon name="search" size={16} /></Text></View>
                            </TouchableWithoutFeedback>
                            <TouchableWithoutFeedback onPress={() => this.showAddhouse(item)}>
                              <View style={styles.updateBtn}>
                                <Text style={styles.updateBtnText}><Icon name="edit" size={16} /></Text></View>
                            </TouchableWithoutFeedback>
                            <TouchableWithoutFeedback onPress={() => this.toogleActDeactiveAlert(item)}>
                              <View style={styles.updateBtn}>
                                <Text style={styles.updateBtnText}><Icon name={item.status == 1 ? "eye-slash" : "eye"} size={16} /></Text></View>
                            </TouchableWithoutFeedback>
                            <TouchableWithoutFeedback onPress={() => this.deleteAlert(item)}>
                              <View style={styles.updateBtn}>
                                <Text style={styles.updateBtnText}><Icon name="trash" size={16} /></Text></View>
                            </TouchableWithoutFeedback>
                          </View>
                      </View>
                    );
                  }
                }}
              />
              
              <TouchableWithoutFeedback onPress={() => this.setState({showAddHouse:true})}>
                <View  style={[styles.addBtnWrapper,styles.shadow]}>
                  <Icon name="plus" color='#fff' size={22} />
                </View>
              </TouchableWithoutFeedback>
            </View>
          }
          
            <Modal
            animationType="slide"
            transparent={false}
            visible={this.state.showAddHouse}
            onRequestClose={() => {
              this.setState({showAddHouse:false, activeHouse: null});
            }}>
              <AddHouse updateHouse={this.state.activeHouse} hideAddhouse={this.hideAddhouse} getAllHouseWithMy={this.getAllHouseWithMy} />
            </Modal>

            <Modal
                animationType="slide"
                transparent={false}
                visible={this.state.showDetails}
                onRequestClose={() => {
                    this.setState({
                        showDetails:true
                    })
                }}
            >
                <HouseDetails hideDetails={this.hideDetails}  />
            </Modal>
        </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    height:'100%',
   // width:'100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  addBtnWrapper:{
    height:50,
    width:50,
    backgroundColor:'#b46def',
    borderRadius:25,
    alignItems:'center',
    justifyContent:'center',
    position:'absolute',
    bottom:20,
    right:'5%',
  },
  newHead:{
    height:40,
    justifyContent:'center'
  },
  newHeadText:{
    fontSize:30,
    fontWeight:'100',
    color:'#000',
    textAlign:'center',
  },
  activeBtnWrapper:{
    marginVertical:10,
    overflow:'hidden',
    borderRadius:30,
    flexDirection:'row',
    width:240,
    borderWidth:2,
    borderColor:'#000',
    alignSelf:'center'
  },
  activeBtn:{
    flex:1,
    justifyContent:'center',
    height:30
  },
  activeBtnText:{
    textAlign:'center',
    color:'#000',
  },
  noItemText:{
    fontSize:14,
    fontWeight:'900',
    color:'#000',
    textAlign:'center',
  },
  addEmptyBtn:{
    marginTop:10,
    paddingHorizontal:20,
    paddingVertical:10,
    borderRadius:30,
    backgroundColor:'#ddd'
  },
  addEmptyBtnText:{
    fontSize:14,
    fontWeight:'900',
    color:'#000',
    textAlign:'center',
  },
  shadow:{
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 2,
    },
    shadowOpacity: 0.34,
    shadowRadius: 2.27,
    elevation: 15,
  },
  shortDetailsText:{
    color:theme().clr,
    fontSize:14,
    fontWeight:'600',
  },
  rent:{
      color:'#b46def',
      fontSize:14,
      fontWeight:'500'
  },
  absoluteText:{
      position:'absolute',
      paddingHorizontal:10,
      paddingVertical:3,
      borderRadius:20,
      backgroundColor:'rgba(0,0,0,0.5)',
      color:'#fff',
      fontSize:12,
      fontWeight:'bold',
      top:10,
      opacity:.8
  },
  shadow:{
      shadowColor: "#000",
      shadowOffset: {
          width: 0,
          height: 6,
      },
      shadowOpacity: 0.8,
      shadowRadius: 10,
      elevation: 5,
  },
  updateBtn:{
    paddingHorizontal:10,
    paddingVertical:5,
  },
  updateBtnText:{
    color:'#000',
    fontSize:30
  }
});
