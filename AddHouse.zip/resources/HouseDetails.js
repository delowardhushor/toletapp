import React, {Component} from 'react';
import {Platform,ScrollView,Dimensions,FlatList, StyleSheet,SafeAreaView, TouchableOpacity,Image, Text, View, TouchableWithoutFeedback, Linking, ToastAndroid} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { theme } from '../lib/theme';
import moment from 'moment';
import { baseurl, get, post, setLocal } from '../lib/utilies';

let {height, width} = Dimensions.get('window');

import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';

type Props = {};
@inject('Store')
@observer
export default class HouseDetails extends Component<Props> {

    constructor(props){
        super(props);
        this.state = {
            loaded:false,
            loved: false,
            activeImage:0,
        };

        setTimeout(() => {
            this.setState({loaded:true});
        }, 100)
    }
    

 componentDidMount(){
    this.checkInLoved()
 }

 handleLoved = (houseDetails) => {
    if(this.state.loved){
        ToastAndroid.show("Removed From Loved", 1000);
        this.setState({loved:false});
        var settings = JSON.parse(JSON.stringify(this.props.Store.settings));
        for(var i = 0; i < settings.loved.length; i++){
            if(houseDetails.id == settings.loved[i]){
                settings.loved.splice(i,1);
                break;
            }
        }
        this.props.Store.settings = settings;
        setLocal('settings', settings);
        var loved = JSON.parse(JSON.stringify(this.props.Store.loved));
        for(var n = 0; n < loved.length; n++){
            if(houseDetails.id == loved[n].id){
                loved.splice(n,1);
                break;
            }
        }
        this.props.Store.loved = loved;
    }else{
        ToastAndroid.show("Added To Loved", 1000);
        this.setState({loved:true});
        var settings = JSON.parse(JSON.stringify(this.props.Store.settings));
        settings.loved.push(houseDetails.id);
        this.props.Store.settings = settings;
        setLocal('settings', settings);
        var loved = JSON.parse(JSON.stringify(this.props.Store.loved));
        loved.push(houseDetails);
        this.props.Store.loved = loved;
    }
 }

 checkInLoved = () => {
    var loved = JSON.parse(JSON.stringify(this.props.Store.settings.loved));
    var id = this.props.Store.houseDetails.id
    var len = loved.length;
    exist = false;
    for(var i = 0; i < len; i++){
        if(id == loved[i]){
            exist = true;
            break;
        }
    }
    this.setState({loved:exist});
 }

 slideForward = () => {
    var houseImages = JSON.parse(this.props.Store.houseDetails.image);
    let {activeImage} = this.state;
    if(activeImage+1 < houseImages.length){
        this.SlideScroll.scrollTo({x:width*(activeImage+1) , y: 0, animated: true});
        this.setState({activeImage:activeImage+1});
    }else{
        this.SlideScroll.scrollTo({x:0 , y: 0, animated: true});
        this.setState({activeImage:0});
    }
 }

 slideBackward = () => {
    var houseImages = JSON.parse(this.props.Store.houseDetails.image);
    let {activeImage} = this.state;
    if(activeImage == 0){
        this.SlideScroll.scrollTo({x:width*(houseImages.length-1) , y: 0, animated: true});
        this.setState({activeImage:houseImages.length-1});
    }else{
        this.SlideScroll.scrollTo({x:width*(activeImage-1) , y: 0, animated: true});
        this.setState({activeImage:activeImage-1});
    }
 }

  render() {

    let {houseDetails} = this.props.Store;
    var houseImages = (JSON.parse(houseDetails.image)).map((item, index)=> {
        return (
            <Image
                key={index}
                source={{uri :baseurl()+'/img/'+item}}
                style={[{width:width, height:250, resizeMode:'cover'}]}
            />
        );
    });

    return (
      <ScrollView style={{flex:1}}>
        {/* <FlatList
            ref={(c) => { this.SlideScroll = c }}
            style={{
                width:width, 
                height:250, 
                flexDirection:'row'
            }} 
            showsHorizontalScrollIndicator={false}
            pagingEnabled={true}
            horizontal={true} 
            data={houseImages}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item, index}) => 
                <Image
                    source={{uri :baseurl()+'/img/'+item}}
                    style={[{width:width, height:250, resizeMode:'cover'}]}
                />
            }
        />  */}
        <ScrollView
            ref={(c) => { this.SlideScroll = c }}
            style={{
                width:width, 
                height:250, 
                flexDirection:'row'
            }} 
            showsHorizontalScrollIndicator={false}
            pagingEnabled={true}
            horizontal={true} 
        >
            {houseImages}
        </ScrollView>
        <View style={{flex:1, padding:20, backgroundColor:'#fff'}}>
            <Text style={{borderBottomWidth:1, borderBottomColor:'#ddd', paddingBottom:5}}><Icon name="list-ul" /> Avaliable Date & Area</Text>
            <View style={{height:30,flexDirection:'row', alignItems:'center', justifyContent:'space-between'}}>
                <Text style={styles.shortDetailsText}><Icon name="calendar" size={12} /> {moment(houseDetails.date).format('Do MMMM YY')}</Text>
                <Text style={styles.shortDetailsText}><Icon name="map-marker" size={12} /> {houseDetails.area}</Text>
            </View>
            <Text style={{borderBottomWidth:1, borderBottomColor:'#ddd', paddingBottom:5, marginTop:20}}><Icon name="list-ul" /> Features</Text>
            <View style={{height:30,flexDirection:'row', alignItems:'center', justifyContent:'space-between'}}>
                <Text style={styles.shortDetailsText}><Icon name="bed" size={12} /> {houseDetails.room} room</Text>
                <Text style={styles.shortDetailsText}><Icon name="bath" size={12} /> {houseDetails.bath} Bathroom</Text>
                <Text style={styles.rent}>{houseDetails.square} sq ft</Text>
            </View>
            <View style={{height:40,flexDirection:'row', alignItems:'center', justifyContent:'space-between', borderBottomWidth:1, borderBottomColor:'#ddd', marginTop:20}}>
                <Text><Icon name="map-signs" /> Full Address</Text>
                <TouchableWithoutFeedback onPress={() => Linking.openURL(houseDetails.location)}>
                    <View style={[styles.directionBtn, styles.shadow]}>
                        <Text style={{color:'#fff'}}><Icon name="map-marker" /> GET DIRECTION</Text>
                    </View>
                </TouchableWithoutFeedback>
            </View>
            <Text style={[styles.shortDetailsText, {width:'100%', marginTop:5, marginBottom:20}]}>{houseDetails.address}</Text>
            <Text style={{borderBottomWidth:1, borderBottomColor:'#ddd', paddingBottom:5, marginTop:10}}><Icon name="info" /> Details</Text>
            <Text style={[styles.shortDetailsText, {width:'100%', marginTop:5, marginBottom:20}]}>{houseDetails.details}</Text>
            <Text style={{borderBottomWidth:1, borderBottomColor:'#ddd', paddingBottom:5, marginTop:10}}><Icon name="list-alt" /> Owner Info</Text>
            <View style={{height:50,flexDirection:'row', alignItems:'center', justifyContent:'space-between'}}>
                <View>
                    <Text style={styles.shortDetailsText}><Icon name="user" size={12} /> {houseDetails.users_name}</Text>
                    <Text style={styles.shortDetailsText}><Icon name="phone" size={12} /> {houseDetails.users_mobile}</Text>
                </View>
                <View style={{flexDirection:'row'}}>
                    <TouchableWithoutFeedback onPress={() => Linking.openURL('tel:'+houseDetails.users_mobile)}>
                        <View style={[styles.callMsgBtn, styles.shadow]}>
                            <Text style={{color:'#fff'}}><Icon name="phone" size={14} /></Text>
                        </View>
                    </TouchableWithoutFeedback>
                    <TouchableWithoutFeedback onPress={() => Linking.openURL('sms:'+houseDetails.users_mobile)}>
                        <View style={[styles.callMsgBtn, styles.shadow]}>
                            <Text style={{color:'#fff'}}><Icon name="wechat" size={14}  /></Text>
                        </View>
                    </TouchableWithoutFeedback>
                </View>
            </View>
            <View style={{height:100}}></View>
        </View>

        {(houseImages.length > 0) && 
        <TouchableWithoutFeedback onPress={() => this.slideBackward()}>
            <View style={[styles.slideTggleBtn, {left:10}]}>
                <Icon size={12} color='#fff' name='chevron-left' />
            </View>
        </TouchableWithoutFeedback>
        }
        {(houseImages.length > 0) && 
        <TouchableWithoutFeedback onPress={() => this.slideForward()}>
            <View style={[styles.slideTggleBtn, {right:10}]}>
                <Icon size={12} color='#fff' name='chevron-right' />
            </View>
        </TouchableWithoutFeedback>
        }
        <TouchableWithoutFeedback onPress={() => this.props.hideDetails()}>
            <View style={[styles.detailsAbsBtn, {left:10}]}>
                <Text style={styles.detailsAbsBtnText}><Icon size={12} name='chevron-left' /></Text>
            </View>
        </TouchableWithoutFeedback>
        <TouchableWithoutFeedback onPress={() => this.handleLoved(houseDetails)}>
            <View style={[styles.detailsAbsBtn, {right:10}]}>
                <Text style={styles.detailsAbsBtnText}><Icon color={this.state.loved ? '#b46def' : "#fff"} size={22} name='heart' /></Text>
            </View>
        </TouchableWithoutFeedback>

      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  shortDetailsText:{
      color:theme().clr,
      fontSize:14,
      fontWeight:'600',
  },
  rent:{
      color:'#b46def',
      fontSize:14,
      fontWeight:'500'
  },
  absoluteText:{
      position:'absolute',
      paddingHorizontal:10,
      paddingVertical:3,
      borderRadius:20,
      backgroundColor:'rgba(0,0,0,0.5)',
      color:'#fff',
      fontSize:12,
      fontWeight:'bold',
      top:10,
      opacity:.8
  },
  shadow:{
      shadowColor: "#000",
      shadowOffset: {
          width: 0,
          height: 6,
      },
      shadowOpacity: 0.8,
      shadowRadius: 10,
      elevation: 5,
  },
  detailsAbsBtn:{
      position:'absolute', 
      top:10,
      height:50, 
      width:50, 
      alignItems:'center', 
      justifyContent:'center',
      backgroundColor:'rgba(0,0,0,.3)',
      borderRadius:5
  },
  slideTggleBtn:{
        top:200,
    position:'absolute', 
      height:50, 
      width:50, 
      alignItems:'center', 
      justifyContent:'center',
  },
  detailsAbsBtnText:{
      fontSize:24, 
      fontWeight:'bold', 
      color:'#fff'
  },
  directionBtn:{
      paddingHorizontal:10,
      paddingVertical:3,
      borderRadius:20,
      backgroundColor:'#b46def'
  },
  callMsgBtn:{
      height:40,
      width:40,
      borderRadius:20,
      alignItems:'center',
      justifyContent:'center',
      backgroundColor:'#b46def',
      marginLeft:5,
  }
});
