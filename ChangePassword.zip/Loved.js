import React, {Component} from 'react';
import { StyleSheet,FlatList,Modal,Image, TouchableWithoutFeedback,Dimensions, Text,View} from 'react-native';
import { theme } from './lib/theme';
import { baseurl} from './lib/utilies';
import Icon from 'react-native-vector-icons/FontAwesome';
import HouseDetails from './resources/HouseDetails';
import _ from 'lodash';
import moment from 'moment';

let {width,height} = Dimensions.get('window');


import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';

type Props = {};
@inject('Store')
@observer
export default class Loved extends Component<Props> {

  constructor(props){
    super(props);
    this.state = {
        showDetails: false,
    };
  }

  componentDidMount(){

  }

  openHouse = (item) => {
    this.setState({showDetails:true})
    this.props.Store.houseDetails = item;
  }

  hideDetails = () => {
      this.setState({showDetails:false});
  }
  
  render() {

    return (
      <View style={{flex:1, backgroundColor:'#fff'}}>
        <View style={[styles.head, styles.shadow]}>
          <Icon name='heart' size={44} color='#fff' />
        </View>
        <Text style={[styles.headTitle,styles.shadow]}>
          <Icon name='heart' size={20} color='#b46def' /> Loved
        </Text>
        <FlatList style={{height:'100%'}}
          data={this.props.Store.houses}
          showsVerticalScrollIndicator={false}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({item, index}) => 
            <TouchableWithoutFeedback onPress={() => this.openHouse(item)}>
                <View style={[{height:260, width:width*.9,alignSelf:'center',marginTop:10,position:'relative', borderRadius:5, marginBottom:10}, styles.shadow]}>
                    <Image 
                        style={{height:220,width:'100%',resizeMode:'cover', borderTopRightRadius:5, borderTopLeftRadius:5}}
                        source={{uri: baseurl()+'/img/'+JSON.parse(item.image)[0]}}
                    />
                    <View style={{height:40,flexDirection:'row', alignItems:'center', justifyContent:'space-around'}}>
                        <Text style={styles.shortDetailsText}><Icon name="bed" size={12} /> {item.room} room</Text>
                        <Text style={styles.shortDetailsText}><Icon name="bath" size={12} /> {item.bath} Bathroom</Text>
                        <Text style={styles.rent}>{item.square} sq ft</Text>
                    </View>
                    <View style={{position:'absolute',height:35, bottom:40, left:0,right:0, backgroundColor:'rgba(0,0,0,0.5)',paddingLeft:10, paddingTop:6, flexDirection:'row'}}>
                        <Text style={{color:'#fff', opacity:.8, fontSize:16, fontWeight:'900'}}>৳{item.cost}</Text>
                        <Text style={{paddingTop:3,color:'#fff', fontSize:12}}> {item.type === 'Sale' ? '' : 'per month'}</Text>
                    </View>
                    <Text style={[styles.absoluteText, {left:10}]}>{item.type}</Text>
                    <Text style={[styles.absoluteText, {right:10}]}>Avaliable Form: {moment(item.date).format('MMMM YY')}</Text>
                    <Text style={[styles.absoluteText, {top:190, left:'auto', right:10}]}><Icon name="map-marker" size={12} /> {item.area}</Text>
                </View>
            </TouchableWithoutFeedback>
          }
        />
        <Modal
            pointerEvents={this.state.showDetails ? 'auto' : 'none'}
            animationType="slide"
            transparent={true}
            visible={this.state.showDetails}
            onRequestClose={() => {
                this.setState({
                    showDetails:true
                })
            }}
        >
          <HouseDetails hideDetails={this.hideDetails}  />
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  head:{
    height:80,
    backgroundColor:'#b46def',
    alignItems:'center',
    justifyContent:'center',
    borderBottomRightRadius:30,
    borderBottomLeftRadius:30,
    paddingBottom:15
  },
  headTitle:{
    alignSelf:'center',
    backgroundColor:'#fff',
    paddingHorizontal:20,
    paddingVertical:5,
    borderRadius:30,
    marginBottom:10,
    marginTop:-20,
    fontSize:20,
    color:'#b46def',
  },
  shortDetailsText:{
    color:theme().clr,
    fontSize:14,
    fontWeight:'600',
  },
  rent:{
      color:'#a3176e',
      fontSize:14,
      fontWeight:'500'
  },
  absoluteText:{
      position:'absolute',
      paddingHorizontal:10,
      paddingVertical:3,
      borderRadius:20,
      backgroundColor:'rgba(0,0,0,0.5)',
      color:'#fff',
      fontSize:12,
      fontWeight:'bold',
      top:10,
      opacity:.8
  },
  shadow:{
      shadowColor: "#000",
      shadowOffset: {
          width: 0,
          height: 6,
      },
      shadowOpacity: 0.8,
      shadowRadius: 10,
      elevation: 5,
  },
  detailsAbsBtn:{
      position:'absolute', 
      top:10,
      height:50, 
      width:50, 
      alignItems:'center', 
      justifyContent:'center',
      backgroundColor:'rgba(0,0,0,.3)',
      borderRadius:5
  },
  detailsAbsBtnText:{
      fontSize:24, 
      fontWeight:'bold', 
      color:'#fff'
  },
  directionBtn:{
      paddingHorizontal:10,
      paddingVertical:3,
      borderRadius:20,
      backgroundColor:'#a3176e'
  },
  callMsgBtn:{
      height:40,
      width:40,
      borderRadius:20,
      alignItems:'center',
      justifyContent:'center',
      backgroundColor:'#a3176e',
      marginLeft:5,
  }
});
