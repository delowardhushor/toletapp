import React, {Component} from 'react';
import {Platform, StyleSheet,TouchableOpacity,Modal, TouchableWithoutFeedback, Text, View} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { theme } from './lib/theme';
import { getLocal, resetLocal } from './lib/utilies';

import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';

import ChangePassword from './ChangePassword';


type Props = {};
@inject('Store')
@observer
export default class Settings extends Component<Props> {

  constructor(props){
    super(props);
    this.state = {
      changePassword: false,
    };
  }

  hideChangePass = () => {
    this.setState({changePassword:false});
  }

  signout = () => {
    resetLocal('user');
    this.props.Store.user = [];
    this.props.Store.myhouse = [];
    this.props.navigation.navigate('Home');
  }

  render() {

    return (
      <View style={styles.container}>
        <View style={[styles.head, styles.shadow]}>
          <Icon name='cogs' size={44} color='#fff' />
        </View>
        <View style={{flex:4}}>
          <Text style={[styles.headTitle,styles.shadow]}>
            <Icon name='cog' size={20} color='#b46def' /> SETTINGS
          </Text>
          <TouchableWithoutFeedback onPress={() => this.setState({changePassword:true})}>
            <View style={[styles.btn, styles.shadow, {marginTop:20}]}>
              <Text style={styles.btnText}><Icon name='key' size={12} color='#b46def' /> Change Password</Text>
            </View>
          </TouchableWithoutFeedback>
          <TouchableWithoutFeedback onPress={() => this.signout()}>
            <View style={[styles.btn, styles.shadow]}>
              <Text style={styles.btnText}><Icon name='user' size={12} color='#b46def' /> Sign Out</Text>
            </View>
          </TouchableWithoutFeedback>
        </View>
        <Modal
          animationType="slide"
          transparent={false}
          visible={this.state.changePassword}
          onRequestClose={() => {
              this.setState({
                changePassword:false
              })
          }}
        >
          <ChangePassword hideChangePass={this.hideChangePass} />
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection:'column',
    backgroundColor:'#fff',
  },
  head:{
    height:80,
    backgroundColor:'#b46def',
    alignItems:'center',
    justifyContent:'center',
    borderBottomRightRadius:30,
    borderBottomLeftRadius:30,
    paddingBottom:15
  },
  headTitle:{
    alignSelf:'center',
    backgroundColor:'#fff',
    paddingHorizontal:20,
    paddingVertical:5,
    borderRadius:30,
    marginTop:-20,
    fontSize:20,
    color:'#b46def',
  },
  btn:{
    borderRadius:10,
    justifyContent:'center',
    width:'80%',
    alignSelf:'center',
    padding:10,
    backgroundColor:'#fff',
    marginTop:2
  },
  btnText:{
    color: '#000',
    fontWeight:'bold',
    fontSize:12
  },
  shadow:{
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 6,
    },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 5,
  }
});
