import React, {Component} from 'react';
import {Platform,Keyboard,ToastAndroid,Slider, CheckBox, ScrollView, StyleSheet,TouchableOpacity, Text, View,Image,Dimensions, TextInput,TouchableNativeFeedback, FlatList, TouchableWithoutFeedback } from 'react-native';
import { theme } from '../lib/theme';
import { baseurl, get, post } from '../lib/utilies';
import Icon from 'react-native-vector-icons/FontAwesome';
import _ from 'lodash';

import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';

let {width, height} = Dimensions.get('window')

type Props = {};
@inject('Store')
@observer
export default class Search extends Component<Props> {

    constructor(props){
        super(props);
        this.state = {
            watchChange:false,
            searchText:'',
            filteredArea:[],
            selectedArea:'',
            type:'Single-Room-Rent',
        };
        this.focusNextField = this.focusNextField.bind(this);
        this.inputs = {};
    }

    focusNextField(name) {
        setTimeout(() => {
          this.inputs[name].focus();
        }, 100);
    }

    search = (area, type) => {
        this.props.Store.loading = true;
        post('/public/api/adds/search', {
            area:area,
            type:type,
        } ,(response) =>{
            if(response.data.success){
              this.props.Store.loading = false;
              this.props.Store.searching = true;
              this.props.Store.search = response.data.Adds;
            }else{
              this.props.Store.loading = false;
              ToastAndroid.show(response.data.msg, 1000);
            }
        })
      }

    searchArea = (searchText) => {
        this.setState({searchText:searchText});
        let {area} = this.props.Store;
        var filteredArea = [];

        for(var i = 0; i < area.length; i++){
            if(area[i].toLowerCase().indexOf(searchText.toLowerCase()) !== -1){
                filteredArea.push(area[i]);
            }
        }
        this.setState({filteredArea:filteredArea});
        this.setState({watchChange:!this.state.watchChange});
    }

    clearSearchText(){
        this.setState({searchText:''});
        this.props.Store.search = [];
        this.props.Store.searching = false;
        Keyboard.dismiss();
    }

    selectArea(area){
        this.search(area, this.state.type);
        this.setState({selectedArea:area});
    }

    selectType(type){
        this.search(this.state.selectedArea, type);
        this.setState({type:type});
    }

    removeArea(){
        this.setState({selectedArea:''});
        this.props.Store.search = [];
        this.props.Store.searching = false;
        this.focusNextField('searchInput');
    }

    render() {
        return (
            <View style={styles.headerWrapper}>
                {this.state.selectedArea === '' ?
                <View style={[styles.header, styles.shadow]}>
                    <TextInput
                        ref={ input => {
                            this.inputs['searchInput'] = input;
                        }}
                        underlineColorAndroid="#fff"
                        selectTextOnFocus={true}
                        style={styles.searchInput}
                        placeholder='Search by Location'
                        value={this.state.searchText}
                        onChangeText={(searchText) => this.searchArea(searchText)}
                    />
                    <TouchableOpacity onPress={() => this.clearSearchText()} style={{flex:.1}}>
                        <Text style={styles.searchIcon}><Icon name={this.state.searchText == '' ? 'search' : 'times'} size={14}  /></Text>
                    </TouchableOpacity>
                </View>
                :
                <TouchableOpacity onPress={() =>  this.removeArea()} style={[styles.header, styles.shadow, {height:40}]}>
                    <Text style={styles.selectAreaText}>{this.state.selectedArea}</Text>
                    <Text style={styles.searchIcon}><Icon name='times' size={15} color={theme().clr2}  /></Text>
                </TouchableOpacity>
                }
                {(this.state.selectedArea !==  '') &&
                <ScrollView 
                    horizontal={true} 
                    showsHorizontalScrollIndicator={false}
                    style={{
                        width:'90%', 
                        flexDirection:'row', 
                    }}
                >
                    <TouchableWithoutFeedback onPress={() => this.selectType('Single-Room-Rent')}>
                        <View style={[styles.typeSelect,{ backgroundColor:this.state.type === 'Single-Room-Rent' ? '#000' : '#fff'}]}>
                            <Text style={[styles.typeSelectText, {color:this.state.type === 'Single-Room-Rent' ? '#fff' : '#000'}]}>Single Room Rent <Icon name="check-circle" color="#ddd" /></Text>
                        </View>
                    </TouchableWithoutFeedback>
                    <TouchableWithoutFeedback onPress={() => this.selectType('Flat-Rent')}>
                        <View style={[styles.typeSelect,{ backgroundColor:this.state.type === 'Flat-Rent' ? '#000' : '#fff'}]}>
                            <Text style={[styles.typeSelectText, {color:this.state.type === 'Flat-Rent' ? '#fff' : '#000'}]}>Flat Rent <Icon name="check-circle" color="#ddd" /></Text>
                        </View>
                    </TouchableWithoutFeedback>
                    <TouchableWithoutFeedback onPress={() => this.selectType('Sub-Late')}>
                        <View style={[styles.typeSelect,{ backgroundColor:this.state.type === 'Sub-Late' ? '#000' : '#fff'}]}>
                            <Text style={[styles.typeSelectText, {color:this.state.type === 'Sub-Late' ? '#fff' : '#000'}]}>Sub Let <Icon name="check-circle" color="#ddd" /></Text>
                        </View>
                    </TouchableWithoutFeedback>
                    <TouchableWithoutFeedback onPress={() => this.selectType('Room-Mate')}>
                        <View style={[styles.typeSelect,{ backgroundColor:this.state.type === 'Room-Mate' ? '#000' : '#fff'}]}>
                            <Text style={[styles.typeSelectText, {color:this.state.type === 'Room-Mate' ? '#fff' : '#000'}]}>Room Mate <Icon name="check-circle" color="#ddd" /></Text>
                        </View>
                    </TouchableWithoutFeedback>
                    <TouchableWithoutFeedback onPress={() => this.selectType('Office-Space')}>
                        <View style={[styles.typeSelect,{ backgroundColor:this.state.type === 'Office-Space' ? '#000' : '#fff'}]}>
                            <Text style={[styles.typeSelectText, {color:this.state.type === 'Office-Space' ? '#fff' : '#000'}]}>Office Space <Icon name="check-circle" color="#ddd" /></Text>
                        </View>
                    </TouchableWithoutFeedback>
                    <TouchableWithoutFeedback onPress={() => this.selectType('Flat-Sale')}>
                        <View style={[styles.typeSelect,{ backgroundColor:this.state.type === 'Flat-Sale' ? '#000' : '#fff'}]}>
                            <Text style={[styles.typeSelectText, {color:this.state.type === 'Flat-Sale' ? '#fff' : '#000'}]}>Falt Sale <Icon name="check-circle" color="#ddd" /></Text>
                        </View>
                    </TouchableWithoutFeedback>
                    <View style={{width:50}}></View>
                </ScrollView>
                }
                {(this.state.filteredArea.length > 0 &&  this.state.selectedArea === ''  && this.state.searchText !== '') &&
                <FlatList
                    keyboardShouldPersistTaps={'always'}
                    extraData={this.state.watchChange}
                    data={this.state.filteredArea}
                    style={{width:'100%'}}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({item, index}) =>
                        
                        <TouchableOpacity onPress={() => this.selectArea(item)} style={[styles.selectItem,{ backgroundColor:'#fff'}]}>
                            <Text style={{fontSize:14,fontWeight:'600', color:'#000'}}>{item}</Text>
                            <Icon name='check' size={14} color="#eee" />
                        </TouchableOpacity>
                    }
                />
                }
                {(this.state.filteredArea.length == 0 && this.state.selectedArea === '' && this.state.searchText !== '') &&
                <View><Text style={styles.noResultText}>No Area Found</Text></View>
                }
            </View>
        );
    }
}

const styles = StyleSheet.create({
  container: {
    alignSelf:'center',
    width:'90%'
  },
  headerWrapper:{
    backgroundColor:'#fff',
    alignItems:'center',
    justifyContent:'center',
    alignSelf:'center',
    width:'100%',
  },
  header:{
    flexDirection:'row', 
    borderRadius:20, 
    backgroundColor:'#fff',
    alignSelf:'center',
    width:'90%',
    justifyContent:'space-between',
    alignItems:'center',
    marginVertical:7,
  },
  areaHeader:{
    flexDirection:'row', 
    borderRadius:20, 
    backgroundColor:'#fff',
    alignSelf:'center',
    width:'90%',
    justifyContent:'space-between',
    alignItems:'center',
    marginVertical:5,
    padding:3,
  },
  searchInput:{
      height:40,
      padding:0,
      fontSize:16,
      paddingHorizontal:15,
      flex:.9,
  },
  selectAreaText:{
    padding:0,
    fontSize:14,
    paddingHorizontal:15,
    flex:.9,
    color:theme().clr,
},
  searchIcon:{
    textAlign:'right',
    paddingRight:15
  },
  areaList:{
    width:Dimensions.get('window').width*.9,
    padding:5, 
    flexDirection:'row', 
    justifyContent:'space-between', 
    alignItems:'center'
  },
  areaName:{
      fontSize:12,
      color:theme().clr,
      fontWeight:'800'
  },
  areaBtn:{
      borderRadius:20,
      padding:5,
      paddingLeft:8,
      backgroundColor:theme().backClr,
      margin:2,
  },
  areabtnText:{
      fontSize:11,
      color:'#fff'
  },
  typeSelect:{
    position:'relative', 
    margin:3, 
    paddingHorizontal:8, 
    paddingVertical:5, 
    borderWidth:1, 
    borderRadius:20,
  },
  typeSelectText:{
      fontSize:12,
      color:'#000'
  },
  rangeTitle:{
      fontSize:10,
      fontWeight:'600',
  },
  noResultText:{
      fontSize:14,
      fontWeight:'800',
      paddingBottom:10,
  },
  selectItem:{
    width:'90%',
    paddingVertical:8,
    paddingHorizontal:20, 
    justifyContent:'space-between',
    alignSelf:'center', 
    alignItems:'center',
    flexDirection:'row', 
    borderRadius:30,
    borderColor:'#ddd',
    borderWidth:.5,
    marginTop:5
  },
  shadow:{
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 6,
    },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 5,
  },
});
