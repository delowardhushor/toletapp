import React from 'react';
import { Text, View } from 'react-native';
import {  createMaterialTopTabNavigator, createStackNavigator } from 'react-navigation';
import Icon from 'react-native-vector-icons/FontAwesome';
import Store from './Store';
import { Provider } from 'mobx-react';


import Home from './Home';
import Settings from './Settings';
import Loved from './Loved';
import Myhouse from './Myhouse';

import HouseDetails from './resources/HouseDetails';


const BottomTab =  createMaterialTopTabNavigator(
  {
    Home: {
      screen: Home,
      navigationOptions:{
        tabBarLabel: 'Home',
        tabBarIcon: ({tintColor}) => (
          <Icon name="home" size={24} color={tintColor} />
        )
      }
    },
    Myhouse: {
      screen: Myhouse,
      navigationOptions:{
        tabBarLabel: 'My house',
        tabBarIcon: ({tintColor}) => (
          <Icon name="map-signs" size={24} color={tintColor} />
        )
      }
    },
    Loved: {
      screen: Loved,
      navigationOptions:{
        tabBarLabel: 'Loved',
        tabBarIcon: ({tintColor}) => (
          <Icon name="heart" size={24} color={tintColor} />
        )
      }
    },
    Settings: {
      screen: Settings,
      navigationOptions:{
        tabBarLabel: 'Settings',
        tabBarIcon: ({tintColor}) => (
          <Icon name="cogs" size={24} color={tintColor} />
        )
      }
    },
  },
  {
    initialRouteName:'Home',
    tabBarPosition: 'bottom',
    tabBarOptions: {
      activeTintColor: '#fff',
      inactiveTintColor: '#ddd',
      style:{
        backgroundColor:'#a3176e',
        height:60
      },
      indicatorStyle:{
        height:0
      },
      showIcon: 0,
      labelStyle: {
        fontSize:10
      },
    },
  }
);

const BottomWithMoel = createStackNavigator(
  {
    Main: {
      screen: BottomTab,
    },
    HouseDetails: {
      screen: HouseDetails,
    },
  },
  {
    mode: 'modal',
    headerMode: 'none',
  }
);

export default class App extends React.Component {
  render() {
    return (
      <Provider Store={Store}>
        <BottomWithMoel />
      </Provider>
    );
  }
}

