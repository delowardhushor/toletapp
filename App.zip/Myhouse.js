import React, {Component} from 'react';
import {Platform, StyleSheet,WebView,TouchableWithoutFeedback,TouchableOpacity, Image, ToastAndroid, Modal,KeyboardAvoidingView,FlatList, ImageBackground,AsyncStorage, ScrollView, Dimensions, Text,TextInput, View} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import moment from 'moment';
import { theme } from './lib/theme';
import Login from './Login';
import {setLocal, getLocal, post, baseurl} from './lib/utilies';
import AddHouse from './AddHouse';
import HouseDetails from './resources/HouseDetails';

let {width,height} = Dimensions.get('window');


import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';

type Props = {};
@inject('Store')
@observer
export default class Myhouse extends Component<Props> {

  constructor(props) {
      super(props);
      this.state = {
          watchChange: true,
          showAddHouse: false,
          activeHouse: null,
          showDetails: false,

          shownType:'active',
      };
  }

  setPendingUser = (mobile, pass) => {
    this.setState({pendingMobile:mobile});
    this.setState({pendingPass:pass});
  }


  changePage = (value) =>{
    this.setState({activeHouse: null, page:value});
  }

  confirmCode = (pin) => {
    post('/verify', {
        mobile:this.state.pendingMobile, 
        password:this.state.pendingPass,
        pin:pin,
    }, (response) => {
        console.log(response);
        if(response.data.success){
            ToastAndroid.show("Welcome to The World Of Home", 3000);
            setLocal('user', response.data.userdata);
            this.changePage('myHouse');
        }else{
            ToastAndroid.show(response.data.msg, 3000);
        }
    });
  }

  showAddhouse = (house) => {
    this.setState({showAddHouse:true,activeHouse:house});
  }

  showHouseDetails = (item) => {
    this.setState({showDetails:true})
    this.props.Store.houseDetails = item;
  }

  hideAddhouse = () => {
    this.setState({showAddHouse:false});
  }

  hideDetails = () => {
    this.setState({showDetails:false});
  }

  toogleShowType = (type) => {
    this.setState({shownType: type});
  }  

  toogleActDeactive = (item) => {
    // post('/public/api/verify', {
    //     mobile:this.state.mobile, 
    //     password:this.state.password,
    //     houseid:this.state.pin,
    // }, (response) => {
    //     if(response.data.success){
    //         ToastAndroid.show("Welcome to The World Of Home", 3000);
    //         setLocal('user', response.data.userdata);
    //         this.props.updateUser(response.data.userdata);
    //         this.props.changePage('myHouse');
    //     }else{
    //         ToastAndroid.show(response.data.msg, 3000);
    //     }
    // });
  }

  delete = () => {
    alert()
  }

  render() {
    
    //const user = JSON.parse(JSON.stringify(this.props.Store.user));

    let {user} = this.props.Store;

    let {myhouse} = this.props.Store;

    return (
        <KeyboardAvoidingView enabled style={{backgroundColor:'#fff', flex:1}}>
          {(user.length == 0) && 
            <Login changePage={this.changePage} />
          }
          {(user.length != 0) && 
            <View style={{position:'relative', flex:1}}>
              <View style={styles.newHead}>
                <Text style={styles.newHeadText}><Icon name="map-signs" size={30} /> MY HOUSE</Text>
              </View>

              
              {(myhouse.length == 0) &&
                <View style={{flex:1, alignItems:'center', justifyContent:'center'}}>
                  <Text style={styles.noItemText}>House list empty</Text>
                  <TouchableWithoutFeedback onPress={() => this.setState({showAddHouse:true})}>
                    <View style={[styles.addEmptyBtn, styles.shadow]}>
                      <Text style={styles.addEmptyBtnText}><Icon name="plus" size={14} /> Add</Text>
                    </View>
                  </TouchableWithoutFeedback>
                </View>
              }

              {(myhouse.length == 0) &&
              <View style={styles.activeBtnWrapper}>
                <TouchableWithoutFeedback onPress={() => this.toogleShowType('active')}>
                  <View style={[styles.activeBtn, {backgroundColor:this.state.shownType == "active" ? "#000" : "#fff" }]}>
                    <Text style={[styles.activeBtnText, {color:this.state.shownType == "active" ? "#fff" : "#000" }]}>Active</Text>
                  </View>
                </TouchableWithoutFeedback>
                <TouchableWithoutFeedback onPress={() => this.toogleShowType('deactive')}>
                  <View style={[styles.activeBtn, {backgroundColor:this.state.shownType != "active" ? "#000" : "#fff" }]}>
                    <Text style={[styles.activeBtnText, {color:this.state.shownType != "active" ? "#fff" : "#000" }]}>Deactivated</Text>
                  </View>
                </TouchableWithoutFeedback>
              </View>
              }
              
              <FlatList
                data={myhouse}
                showsVerticalScrollIndicator={false}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({item, index}) => 

                      <View style={[{height:300, width:width*.9,alignSelf:'center',marginTop:10,position:'relative', borderRadius:5, marginBottom:10}, styles.shadow]}>
                          <Image 
                              style={{height:220,width:'100%',resizeMode:'cover', borderTopRightRadius:5, borderTopLeftRadius:5}}
                              source={{uri: baseurl()+'/img/'+JSON.parse(item.image)[0]}}
                          />
                          <View style={{height:40,flexDirection:'row', alignItems:'center', justifyContent:'space-around'}}>
                              <Text style={styles.shortDetailsText}><Icon name="bed" size={12} /> {item.room} room</Text>
                              <Text style={styles.shortDetailsText}><Icon name="bath" size={12} /> {item.bath} Bathroom</Text>
                              <Text style={styles.rent}>{item.square} sq ft</Text>
                          </View>
                          <View style={{position:'absolute',height:35, bottom:80, left:0,right:0, backgroundColor:'rgba(0,0,0,0.5)',paddingLeft:10, paddingTop:6, flexDirection:'row'}}>
                              <Text style={{color:'#fff', opacity:.8, fontSize:16, fontWeight:'900'}}>৳{item.cost}</Text>
                              <Text style={{paddingTop:3,color:'#fff', fontSize:12}}> {item.type === 'Sale' ? '' : 'per month'}</Text>
                          </View>
                          <Text style={[styles.absoluteText, {left:10}]}>{item.type}</Text>
                          <Text style={[styles.absoluteText, {right:10}]}>Avaliable Form: {moment(item.date).format('MMMM YY')}</Text>
                          <Text style={[styles.absoluteText, {top:190, left:'auto', right:10}]}><Icon name="map-marker" size={12} /> {item.area}</Text>
                          <View style={{height:40, flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal:20}}>
                            <TouchableWithoutFeedback onPress={() => this.showHouseDetails(item)}>
                              <View style={styles.updateBtn}>
                                <Text style={styles.updateBtnText}><Icon name="eye" /> Details</Text></View>
                            </TouchableWithoutFeedback>
                            <TouchableWithoutFeedback onPress={() => this.showAddhouse(item)}>
                              <View style={styles.updateBtn}>
                                <Text style={styles.updateBtnText}><Icon name="edit" /> Update</Text></View>
                            </TouchableWithoutFeedback>
                            <TouchableWithoutFeedback onPress={() => this.toogleActDeactive(item)}>
                              <View style={styles.updateBtn}>
                                <Text style={styles.updateBtnText}><Icon name="eye-slash" /> Update</Text></View>
                            </TouchableWithoutFeedback>
                            <TouchableWithoutFeedback onPress={() => this.delete(item)}>
                              <View style={styles.updateBtn}>
                                <Text style={styles.updateBtnText}><Icon name="trash" /> Update</Text></View>
                            </TouchableWithoutFeedback>
                          </View>
                      </View>

                }
              />
              
              <TouchableWithoutFeedback onPress={() => this.setState({showAddHouse:true})}>
                <View  style={[styles.addBtnWrapper,styles.shadow]}>
                  <Icon name="plus" color='#fff' size={22} />
                </View>
              </TouchableWithoutFeedback>
            </View>
          }
          
            <Modal
            animationType="slide"
            transparent={false}
            visible={this.state.showAddHouse}
            onRequestClose={() => {
              this.setState({showAddHouse:false, activeHouse: null});
            }}>
              <AddHouse updateHouse={this.state.activeHouse} hideAddhouse={this.hideAddhouse} />
            </Modal>

            <Modal
                animationType="slide"
                transparent={false}
                visible={this.state.showDetails}
                onRequestClose={() => {
                    this.setState({
                        showDetails:true
                    })
                }}
            >
                <HouseDetails hideDetails={this.hideDetails}  />
            </Modal>
        </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    height:'100%',
   // width:'100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  addBtnWrapper:{
    height:50,
    width:50,
    backgroundColor:'#b46def',
    borderRadius:25,
    alignItems:'center',
    justifyContent:'center',
    position:'absolute',
    bottom:20,
    right:'5%',
  },
  newHead:{
    height:40,
    justifyContent:'center'
  },
  newHeadText:{
    fontSize:30,
    fontWeight:'100',
    color:'#000',
    textAlign:'center',
  },
  activeBtnWrapper:{
    marginTop:10,
    overflow:'hidden',
    borderRadius:30,
    flexDirection:'row',
    width:240,
    borderWidth:2,
    borderColor:'#000',
    alignSelf:'center'
  },
  activeBtn:{
    flex:1,
    justifyContent:'center',
    height:30
  },
  activeBtnText:{
    textAlign:'center',
    color:'#000',
  },
  noItemText:{
    fontSize:14,
    fontWeight:'900',
    color:'#000',
    textAlign:'center',
  },
  addEmptyBtn:{
    marginTop:10,
    paddingHorizontal:20,
    paddingVertical:10,
    borderRadius:30,
    backgroundColor:'#ddd'
  },
  addEmptyBtnText:{
    fontSize:14,
    fontWeight:'900',
    color:'#000',
    textAlign:'center',
  },
  shadow:{
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 2,
    },
    shadowOpacity: 0.34,
    shadowRadius: 2.27,
    elevation: 15,
  },
  shortDetailsText:{
    color:theme().clr,
    fontSize:14,
    fontWeight:'600',
  },
  rent:{
      color:'#b46def',
      fontSize:14,
      fontWeight:'500'
  },
  absoluteText:{
      position:'absolute',
      paddingHorizontal:10,
      paddingVertical:3,
      borderRadius:20,
      backgroundColor:'rgba(0,0,0,0.5)',
      color:'#fff',
      fontSize:12,
      fontWeight:'bold',
      top:10,
      opacity:.8
  },
  shadow:{
      shadowColor: "#000",
      shadowOffset: {
          width: 0,
          height: 6,
      },
      shadowOpacity: 0.8,
      shadowRadius: 10,
      elevation: 5,
  },
  updateBtn:{
    backgroundColor:'#b46def',
    paddingHorizontal:10,
    paddingVertical:5,
    borderRadius:20,
  },
  updateBtnText:{
    color:'#fff',
    fontSize:10
  }
});
