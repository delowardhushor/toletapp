import React, {Component} from 'react';
import {Platform, StyleSheet,TouchableOpacity,TouchableWithoutFeedback, Text, View} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { theme } from './lib/theme';
import { getLocal, resetLocal } from './lib/utilies';

import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';


type Props = {};
@inject('Store')
@observer
export default class Settings extends Component<Props> {

  constructor(props){
    super(props);
    this.state = {
    };
  }

  signout = () => {
    resetLocal('user');
    this.props.Store.user = [];
    this.props.Store.myhouse = [];
    this.props.navigation.navigate('Home');
  }

  render() {

    return (
      <View style={styles.container}>
        <View style={styles.head}>
          <Icon name='cogs' size={44} color='#fff' />
        </View>
        <View style={{flex:4}}>
          <Text style={[styles.headTitle,styles.shadow]}>
            <Icon name='cog' size={20} color='#000' /> SETTINGS
          </Text>
          <TouchableWithoutFeedback>
            <View style={[styles.btn, styles.shadow, {marginTop:20}]}>
              <Text style={styles.btnText}>Change Password</Text>
            </View>
          </TouchableWithoutFeedback>
          <TouchableWithoutFeedback onPress={() => this.signout()}>
            <View style={[styles.btn, styles.shadow]}>
              <Text style={styles.btnText}><Icon name='user' size={12} color='#000' /> Sign Out</Text>
            </View>
          </TouchableWithoutFeedback>
        </View>
        
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection:'column',
    backgroundColor:'#fff',
  },
  head:{
    flex:1,
    backgroundColor:'#a3176e',
    alignItems:'center',
    justifyContent:'center',
    borderBottomRightRadius:20,
    borderBottomLeftRadius:20,
    paddingBottom:10
  },
  headTitle:{
    alignSelf:'center',
    backgroundColor:'#fff',
    paddingHorizontal:20,
    paddingVertical:5,
    borderRadius:30,
    marginTop:-20,
    fontSize:20,
    color:'#000',
  },
  btn:{
    borderRadius:10,
    justifyContent:'center',
    width:'80%',
    alignSelf:'center',
    padding:10,
    backgroundColor:'#fff',
    marginTop:2
  },
  btnText:{
    color: '#000',
    fontWeight:'bold',
    fontSize:12
  },
  shadow:{
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 6,
    },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 5,
  }
});
