import {
  observable,
  action,
  computed,
  toJS
} from 'mobx';
import {ToastAndroid, Alert} from 'react-native';
import {post, setLocal, getLocal, get, resetLocal } from './lib/utilies';


class AppStore {

  @observable loading = false;
  @observable withMyHouseFailed = false;
  @observable hasConnection = true;
  @observable houses = [];
  @observable user = [];
  @observable settings = {
    loved:[],
  };
  @observable loved = [];
  @observable area = [];
  @observable myhouse = [];
  @observable search = [];
  @observable searching = false;
  @observable houseDetails = {
    image:"[\"default.png\"]",
    type:'',
    area:'',
    room:'',
    bath:'',
    users_name:'',
    users_mobile:'',
    location:'',
    cost:'',
    details:'',
    address:'',
    id:'',
    users_id:'',
    square:''
  };
  

  constructor() {
    this.getInitialData();
  }

  async getInitialData(){
    var user = await getLocal('user');
    // var settings = await getLocal('settings');
    // if(settings != null){
    //   this.settings = settings;
    // }
    if(user != null){
      this.user = user;
      this.getAllHouseWithMy(user);
    }else{
      this.getAllHouse();
    }
    this.loadArea();
  }

  getAllHouseWithMy = (user) => {
    post('/public/api/adds/withmyhouse',{
      mobile:user.mobile,
      token:user.token
    }, (response) => {
      if(response.data.success){
        this.houses = response.data.Adds;
        this.myhouse = response.data.Myhouse;
      }else{
        this.withMyHouseFailed = true;
        this.getAllHouse();
      }
    })
  }

  getAllHouse = () => {
    get('/public/api/adds', (response) =>{
        if(response.data.success){
          if(this.withMyHouseFailed){
            ToastAndroid.show("Session Expired", 1000);
            this.user = [];
            this.myhouse = [];
            resetLocal('user');
          }
          this.houses = response.data.Adds;
        }else{
          ToastAndroid.show("No Network Connection", 1000);
          this.withMyHouseFailed = false;
          this.hasConnection = false;
          this.showNoInternetAlert();
        }
    })
  }

  loadArea = () => {
    get('/storage/area.json', (response) => {
      this.area = response.data;
    })
  }

  showNoInternetAlert = () => {
    Alert.alert(
      "No Connection",
      "Please make sure your wifi or mobile data is on",
      [
        {text: 'RETRY?', onPress: () => this.getInitialData()},
      ],
      {cancelable: false},
    );
  }

}

const singleton = new AppStore();
export default singleton;