import React, {Component} from 'react';
import {Platform,ScrollView,ToastAndroid, StyleSheet,TouchableOpacity, TouchableWithoutFeedback, Text, View} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { theme } from './lib/theme';
import { getLocal, resetLocal, post, baseurl } from './lib/utilies';

import FloatingLabelInput from './resources/FloatingLabelInput';

import { action, observable } from 'mobx';
import {inject,observer} from 'mobx-react';


type Props = {};
@inject('Store')
@observer
export default class ChangePassword extends Component<Props> {

  constructor(props){
    super(props);
    this.state = {
        oldPass:'',
        newPass:'',
        conPass:'',
    };
    this.focusNextField = this.focusNextField.bind(this);
    this.inputs = {};
  }

  focusNextField = (id, position) => {
    this.inputs[id].focusNextField();
  }

  hideChangePass = () => {
    this.setState({changePassword:false});
  }

  signout = () => {
    resetLocal('user');
    this.props.Store.user = [];
    this.props.Store.myhouse = [];
    this.props.navigation.navigate('Home');
  }

  changePassword = () => {
    let {oldPass, newPass, conPass} = this.state;
    if(oldPass && newPass && conPass){
        if(newPass === conPass){
          this.props.Store.loading = true;
          post('/public/api/cngpass', {
              oldPass:oldPass,
              newPass:newPass,
              mobile:this.props.Store.user.mobile,
              token:this.props.Store.user.token
          }, (response) => {
              if(response.data.success === true){
                this.props.Store.loading = false;
                ToastAndroid.show('Password Updated', 1000);
                this.props.hideChangePass();
              }else{
                this.props.Store.loading = false;
                ToastAndroid.show(response.data.msg, 1000);
              }
          });
        }else{
            ToastAndroid.show("Confirm Password Didn't Matched", 1000);
        }
    }else{
        ToastAndroid.show('Fill Empty', 1000);
    }
  }



  render() {

    return (
      <View style={styles.container}>
        <View style={[styles.head, styles.shadow]}>
          <Icon name='key' size={44} color='#fff' />
          <TouchableWithoutFeedback onPress={() => this.props.hideChangePass()}>
              <View style={styles.backBtn}>
                <Text><Icon name="chevron-left" color='#fff' size={14} /></Text>
              </View>
          </TouchableWithoutFeedback>
        </View>
        <View style={{flex:1}}>
          <Text style={[styles.headTitle,styles.shadow]}>
            <Icon name='key' size={20} color='#b46def' /> Change Password
          </Text>
          <ScrollView style={{flex:1, width:'90%', alignSelf:'center'}}>
            <FloatingLabelInput
                selectTextOnFocus={true}
                returnKeyType='next'
                blurOnSubmit={false}
                keyboardType='numeric'
                label="Current Password"
                value={this.state.oldPass}
                secureTextEntry={true}
                onChangeText={(oldPass) => this.setState({oldPass:oldPass})}
                ref={ input => {
                this.inputs['oldPass'] = input;
                }}
                onSubmitEditing={() => {
                    this.focusNextField('newPass');
                }}
            />
            <FloatingLabelInput
                selectTextOnFocus={true}
                returnKeyType='next'
                blurOnSubmit={false}
                keyboardType='numeric'
                label="New Password"
                value={this.state.newPass}
                secureTextEntry={true}
                onChangeText={(newPass) => this.setState({newPass:newPass})}
                ref={ input => {
                this.inputs['newPass'] = input;
                }}
                onSubmitEditing={() => {
                    this.focusNextField('conPass');
                }}
            />
            <FloatingLabelInput
                selectTextOnFocus={true}
                returnKeyType='next'
                blurOnSubmit={false}
                keyboardType='numeric'
                label="Confirm New Password"
                value={this.state.conPass}
                secureTextEntry={true}
                onChangeText={(conPass) => this.setState({conPass:conPass})}
                ref={ input => {
                this.inputs['conPass'] = input;
                }}
                onSubmitEditing={() => {
                    this.changePassword();
                }}
            />
            <TouchableWithoutFeedback onPress={() => this.changePassword()}>
              <View style={[styles.cngBtn, styles.shadow]}>
                <Text style={{color:'#b46def', fontSize:16}}><Icon name="key" color="#b46def" /> Change</Text>
              </View>
            </TouchableWithoutFeedback>
            <View style={{height:100}}></View>
          </ScrollView>
          
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection:'column',
    backgroundColor:'#fff',
  },
  head:{
    height:80,
    backgroundColor:'#b46def',
    alignItems:'center',
    justifyContent:'center',
    borderBottomRightRadius:30,
    borderBottomLeftRadius:30,
    paddingBottom:15
  },
  headTitle:{
    alignSelf:'center',
    backgroundColor:'#fff',
    paddingHorizontal:20,
    paddingVertical:5,
    borderRadius:30,
    marginTop:-20,
    fontSize:20,
    color:'#b46def',
  },
  btn:{
    borderRadius:10,
    justifyContent:'center',
    width:'80%',
    alignSelf:'center',
    padding:10,
    backgroundColor:'#fff',
    marginTop:2
  },
  btnText:{
    color: '#000',
    fontWeight:'bold',
    fontSize:12
  },
  backBtn:{
    position:"absolute", 
    height:50,
    width:50, 
    alignItems:'center', 
    justifyContent:'center', 
    top:10,
    left:10
  },
  cngBtn:{
    paddingHorizontal:10,
    paddingVertical:10,
    borderRadius:20,
    marginTop:20,
    alignSelf:'center',
    backgroundColor:'#fff'
  },
  shadow:{
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 6,
    },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 5,
  }
});
